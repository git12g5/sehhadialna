import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  TextInput,
  StyleSheet,
  SafeAreaView,
  Alert,
} from 'react-native';
import { Search, User, Baby, Heart, Apple, Bot, TriangleAlert as AlertTriangle, Calendar, MapPin } from 'lucide-react-native';

export default function HomeScreen() {
  const handleEmergency = () => {
    Alert.alert(
      'طوارئ',
      'سيتم الاتصال بخدمات الطوارئ',
      [{ text: 'موافق', style: 'default' }],
      { cancelable: true }
    );
  };

  const handleCategoryPress = (category: string) => {
    Alert.alert('تصنيف', `تم اختيار: ${category}`);
  };

  const handleServicePress = (service: string) => {
    Alert.alert('خدمة', `تم اختيار: ${service}`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header with Logo and Slogan */}
        <View style={styles.header}>
          <Text style={styles.appName}>صحة ديالنا</Text>
          <Text style={styles.slogan}>طبيبك ديما معك</Text>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchInputContainer}>
            <Search size={24} color="#6B7280" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="شنو كتقلب عليه؟"
              placeholderTextColor="#9CA3AF"
            />
          </View>
        </View>

        {/* Health Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الأقسام الصحية</Text>
          <View style={styles.categoriesGrid}>
            <TouchableOpacity
              style={[styles.categoryButton, { backgroundColor: '#FDF2F8' }]}
              onPress={() => handleCategoryPress('صحة المرأة')}
            >
              <User size={32} color="#EC4899" />
              <Text style={styles.categoryText}>صحة المرأة</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.categoryButton, { backgroundColor: '#FEF3C7' }]}
              onPress={() => handleCategoryPress('صحة الطفل')}
            >
              <Baby size={32} color="#F59E0B" />
              <Text style={styles.categoryText}>صحة الطفل</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.categoryButton, { backgroundColor: '#FEE2E2' }]}
              onPress={() => handleCategoryPress('الأمراض المزمنة')}
            >
              <Heart size={32} color="#EF4444" />
              <Text style={styles.categoryText}>الأمراض المزمنة</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.categoryButton, { backgroundColor: '#DCFCE7' }]}
              onPress={() => handleCategoryPress('التغذية والوقاية')}
            >
              <Apple size={32} color="#22C55E" />
              <Text style={styles.categoryText}>التغذية والوقاية</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Main Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الخدمات الرئيسية</Text>
          
          <TouchableOpacity
            style={[styles.serviceButton, { backgroundColor: '#22C55E' }]}
            onPress={() => handleServicePress('روبو طبي')}
          >
            <Bot size={36} color="#ffffff" />
            <Text style={styles.serviceButtonText}>روبو طبي</Text>
            <Text style={styles.serviceSubtext}>اسأل عن أي مشكلة صحية</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.serviceButton, { backgroundColor: '#EF4444' }]}
            onPress={handleEmergency}
          >
            <AlertTriangle size={36} color="#ffffff" />
            <Text style={styles.serviceButtonText}>زر الطوارئ</Text>
            <Text style={styles.serviceSubtext}>للحالات العاجلة فقط</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.serviceButton, { backgroundColor: '#3B82F6' }]}
            onPress={() => handleServicePress('حجز مع الطبيب')}
          >
            <Calendar size={36} color="#ffffff" />
            <Text style={styles.serviceButtonText}>حجز مع الطبيب</Text>
            <Text style={styles.serviceSubtext}>استشارة مباشرة أو عبر الفيديو</Text>
          </TouchableOpacity>
        </View>

        {/* Health Centers Map */}
        <View style={styles.section}>
          <TouchableOpacity
            style={styles.mapButton}
            onPress={() => handleServicePress('خريطة المراكز الصحية')}
          >
            <MapPin size={28} color="#22C55E" />
            <Text style={styles.mapButtonText}>خريطة المراكز الصحية</Text>
          </TouchableOpacity>
        </View>

        {/* Bottom Spacing */}
        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    alignItems: 'center',
    paddingVertical: 30,
    paddingHorizontal: 20,
    backgroundColor: '#F8FAFC',
  },
  appName: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#22C55E',
    textAlign: 'center',
    marginBottom: 8,
  },
  slogan: {
    fontSize: 18,
    color: '#6B7280',
    textAlign: 'center',
    fontWeight: '500',
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 18,
    color: '#374151',
    textAlign: 'right',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
    textAlign: 'right',
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  categoryButton: {
    width: '48%',
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  categoryText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginTop: 8,
    textAlign: 'center',
  },
  serviceButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 20,
    borderRadius: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  serviceButtonText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    marginLeft: 16,
    flex: 1,
    textAlign: 'right',
  },
  serviceSubtext: {
    fontSize: 14,
    color: '#ffffff',
    opacity: 0.9,
    marginTop: 4,
    textAlign: 'right',
  },
  mapButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    borderRadius: 16,
    backgroundColor: '#F0FDF4',
    borderWidth: 2,
    borderColor: '#22C55E',
  },
  mapButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#22C55E',
    marginLeft: 12,
  },
  bottomSpacing: {
    height: 20,
  },
});
import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { User, Calendar, Bell, Shield, Heart, Settings, CircleHelp as HelpCircle, LogOut } from 'lucide-react-native';

export default function ProfileScreen() {
  const profileOptions = [
    { icon: Calendar, title: 'سجل المواعيد', subtitle: 'تاريخ جميع المواعيد' },
    { icon: Heart, title: 'الحالة الصحية', subtitle: 'معلومات عن صحتك' },
    { icon: Bell, title: 'الإشعارات', subtitle: 'إعدادات التنبيهات' },
    { icon: Shield, title: 'الخصوصية والأمان', subtitle: 'حماية بياناتك' },
    { icon: Settings, title: 'الإعدادات', subtitle: 'إعدادات التطبيق' },
    { icon: HelpCircle, title: 'المساعدة والدعم', subtitle: 'الأسئلة الشائعة' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>الملف الشخصي</Text>
        </View>

        {/* Profile Info */}
        <View style={styles.profileSection}>
          <View style={styles.profileCard}>
            <View style={styles.avatarContainer}>
              <User size={48} color="#22C55E" />
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.userName}>أحمد محمد</Text>
              <Text style={styles.userEmail}>ahmed.mohamed@email.com</Text>
              <Text style={styles.userAge}>العمر: 45 سنة</Text>
            </View>
            <TouchableOpacity style={styles.editButton}>
              <Text style={styles.editButtonText}>تعديل</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Health Summary */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الملخص الصحي</Text>
          <View style={styles.healthSummary}>
            <View style={styles.healthItem}>
              <Text style={styles.healthLabel}>آخر فحص</Text>
              <Text style={styles.healthValue}>15 يناير 2024</Text>
            </View>
            <View style={styles.healthItem}>
              <Text style={styles.healthLabel}>الأدوية</Text>
              <Text style={styles.healthValue}>3 أدوية</Text>
            </View>
            <View style={styles.healthItem}>
              <Text style={styles.healthLabel}>التطعيمات</Text>
              <Text style={styles.healthValue}>محدثة</Text>
            </View>
          </View>
        </View>

        {/* Profile Options */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الإعدادات</Text>
          {profileOptions.map((option, index) => (
            <TouchableOpacity key={index} style={styles.optionCard}>
              <View style={styles.optionIcon}>
                <option.icon size={24} color="#22C55E" />
              </View>
              <View style={styles.optionContent}>
                <Text style={styles.optionTitle}>{option.title}</Text>
                <Text style={styles.optionSubtitle}>{option.subtitle}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Logout Button */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.logoutButton}>
            <LogOut size={20} color="#EF4444" />
            <Text style={styles.logoutText}>تسجيل الخروج</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F2937',
    textAlign: 'right',
    marginBottom: 8,
  },
  profileSection: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  profileCard: {
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    alignItems: 'center',
  },
  avatarContainer: {
    backgroundColor: '#DCFCE7',
    borderRadius: 50,
    padding: 20,
    marginBottom: 16,
  },
  profileInfo: {
    alignItems: 'center',
    marginBottom: 16,
  },
  userName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: '#6B7280',
    marginBottom: 4,
  },
  userAge: {
    fontSize: 14,
    color: '#6B7280',
  },
  editButton: {
    backgroundColor: '#22C55E',
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  editButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
    textAlign: 'right',
  },
  healthSummary: {
    backgroundColor: '#F0FDF4',
    borderRadius: 16,
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  healthItem: {
    alignItems: 'center',
  },
  healthLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
  },
  healthValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#22C55E',
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  optionIcon: {
    marginRight: 16,
  },
  optionContent: {
    flex: 1,
    alignItems: 'flex-end',
  },
  optionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 2,
  },
  optionSubtitle: {
    fontSize: 12,
    color: '#6B7280',
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FEF2F2',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  logoutText: {
    color: '#EF4444',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
  bottomSpacing: {
    height: 20,
  },
});
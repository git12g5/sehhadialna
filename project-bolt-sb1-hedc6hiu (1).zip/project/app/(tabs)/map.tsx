import React from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import { MapPin, Phone, Clock, Star } from 'lucide-react-native';

export default function MapScreen() {
  const healthCenters = [
    {
      id: 1,
      name: 'مركز الصحة الأولي - الرباط',
      address: 'شارع الحسن الثاني، الرباط',
      phone: '0537-123456',
      hours: '8:00 ص - 8:00 م',
      rating: 4.5,
      distance: '2.5 كم',
    },
    {
      id: 2,
      name: 'مستشفى محمد الخامس',
      address: 'طريق الدار البيضاء، الرباط',
      phone: '0537-789012',
      hours: '24 ساعة',
      rating: 4.8,
      distance: '5.1 كم',
    },
    {
      id: 3,
      name: 'عيادة الأطفال الخاصة',
      address: 'حي الشاطئ، الرباط',
      phone: '0537-345678',
      hours: '9:00 ص - 6:00 م',
      rating: 4.3,
      distance: '3.8 كم',
    },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>خريطة المراكز الصحية</Text>
          <Text style={styles.subtitle}>أقرب المراكز الصحية إليك</Text>
        </View>

        {/* Map Placeholder */}
        <View style={styles.mapContainer}>
          <View style={styles.mapPlaceholder}>
            <MapPin size={48} color="#22C55E" />
            <Text style={styles.mapPlaceholderText}>خريطة المراكز الصحية</Text>
            <Text style={styles.mapSubtext}>اضغط لفتح الخريطة التفاعلية</Text>
          </View>
        </View>

        {/* Health Centers List */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>المراكز القريبة منك</Text>
          {healthCenters.map((center) => (
            <TouchableOpacity key={center.id} style={styles.centerCard}>
              <View style={styles.centerHeader}>
                <View style={styles.centerInfo}>
                  <Text style={styles.centerName}>{center.name}</Text>
                  <Text style={styles.centerAddress}>{center.address}</Text>
                </View>
                <View style={styles.distanceBadge}>
                  <Text style={styles.distanceText}>{center.distance}</Text>
                </View>
              </View>

              <View style={styles.centerDetails}>
                <View style={styles.detailRow}>
                  <Phone size={16} color="#6B7280" />
                  <Text style={styles.detailText}>{center.phone}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Clock size={16} color="#6B7280" />
                  <Text style={styles.detailText}>{center.hours}</Text>
                </View>
                <View style={styles.detailRow}>
                  <Star size={16} color="#F59E0B" />
                  <Text style={styles.detailText}>{center.rating} نجمة</Text>
                </View>
              </View>

              <View style={styles.centerActions}>
                <TouchableOpacity style={styles.actionButton}>
                  <Text style={styles.actionButtonText}>الاتجاهات</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionButton, styles.callButton]}>
                  <Text style={[styles.actionButtonText, styles.callButtonText]}>اتصال</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1F2937',
    textAlign: 'right',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
    textAlign: 'right',
  },
  mapContainer: {
    marginHorizontal: 20,
    marginVertical: 20,
  },
  mapPlaceholder: {
    backgroundColor: '#F0FDF4',
    borderRadius: 16,
    padding: 40,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#22C55E',
    borderStyle: 'dashed',
  },
  mapPlaceholderText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#22C55E',
    marginTop: 12,
    textAlign: 'center',
  },
  mapSubtext: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
    textAlign: 'center',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 16,
    textAlign: 'right',
  },
  centerCard: {
    backgroundColor: '#F9FAFB',
    borderRadius: 16,
    padding: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  centerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  centerInfo: {
    flex: 1,
  },
  centerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    textAlign: 'right',
    marginBottom: 4,
  },
  centerAddress: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'right',
  },
  distanceBadge: {
    backgroundColor: '#DBEAFE',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
  },
  distanceText: {
    fontSize: 12,
    color: '#1D4ED8',
    fontWeight: '600',
  },
  centerDetails: {
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    justifyContent: 'flex-end',
  },
  detailText: {
    fontSize: 14,
    color: '#374151',
    marginRight: 8,
  },
  centerActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#22C55E',
    paddingVertical: 12,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  callButton: {
    backgroundColor: '#F3F4F6',
  },
  callButtonText: {
    color: '#3B82F6',
  },
  bottomSpacing: {
    height: 20,
  },
});